ALTER TABLE students 
RENAME COLUMN student_id TO student_code;